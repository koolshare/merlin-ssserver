#!/bin/sh

rm -rf /koolshare/bin/ssserver
rm -rf /koolshare/ssserver
rm -rf /koolshare/init.d/koolshare/init.d/S66ssserver.sh
rm -rf /koolshare/scripts/ssserver_config.sh
rm -rf /koolshare/webs/Module_ssserver.asp
rm -rf /koolshare/scripts/uninstall_ssserver.sh

